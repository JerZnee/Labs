#include <stdio.h>
#include <stdbool.h>
typedef enum {
	nach,
	chif,
	eslim,
	eslii,
	byaka
}state_t;
int f(double a){
	a=a*1.609;
	printf("%.3fkm\n ", a);
	return 0;
}
int main(){
	state_t st;
	st=nach;
	double n=0;
	do {
		int c = getchar();
		if (st==nach){
			if (c>='0' && c<='9'){
				n=c-'0'; st=chif;
			}
			else if (c==' '||c==10) {
				st=nach; n=0;
			} else if (c == EOF) {
				f(n); 
			}
			else {
				st=byaka;
			}
		}
		else if (st==chif){
			if (c=='m') {
				st=eslim;
			}
			else if (c>='0' && c<='9'){
				st=chif; n=10*n+c-'0';
			}
			else if (c==' '|| c=='\n' || c=='\t') {
				st=nach; n=0;
			}
			else {
				st=byaka;
			}
		}
		else if (st==eslim){
			if (c=='i') {
				st=eslii;
			}
			else if (c==' '|| c=='\t' || c=='\n') {
				st=nach; n=0;
			}
			else {
				st=byaka;
			}
		}
		else if (st==eslii){
			if (c==' '||c=='\t' || c=='\n' || c == EOF){
				st=nach; f(n); n=0;
			}
			else {
				st=byaka;
			}
		}
		else if (st==byaka){
			if (c==' '||c=='\t' || c=='\n') {
				st=nach; n=0;
			}
			else {
				st=byaka;
			}
		
		}
	} while (c != EOF);
}
